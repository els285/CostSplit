# CostSplit
"Split-wise" inspired code for calculating income and expenditure for large parties.

Initially written in Python, but now being translated into Ruby with a web-app based interface to follow.
